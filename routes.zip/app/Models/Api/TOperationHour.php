<?php

namespace App\Models\Api;

use Illuminate\Database\Eloquent\Model;

class TOperationHour extends Model
{
    protected $guarded = [];
}
