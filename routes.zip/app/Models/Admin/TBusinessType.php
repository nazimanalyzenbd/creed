<?php

namespace App\Models\Admin;

use Illuminate\Database\Eloquent\Model;

class TBusinessType extends Model
{
    protected $guarded = [];
}
