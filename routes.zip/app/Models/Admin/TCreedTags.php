<?php

namespace App\Models\Admin;

use Illuminate\Database\Eloquent\Model;

class TCreedTags extends Model
{
    protected $guarded = [];
}
