<?php

namespace App\Models\Admin;

use Illuminate\Database\Eloquent\Model;

class TAdminAffiliation extends Model
{
    protected $guarded = [];
}
