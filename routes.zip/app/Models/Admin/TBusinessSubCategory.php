<?php

namespace App\Models\Admin;

use Illuminate\Database\Eloquent\Model;

class TBusinessSubCategory extends Model
{
    //
}
