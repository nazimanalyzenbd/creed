<?php

namespace App\Models\Admin;

use Illuminate\Database\Eloquent\Model;

class TBusinessCategory extends Model
{
    protected $guarded = [];
}
