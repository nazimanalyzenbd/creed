<?php

namespace App\Models\Admin;

use Illuminate\Database\Eloquent\Model;

class TAdminRestaurant extends Model
{
    protected $guarded = [];
}
