
    <a href="{{route('redirect.google')}}">
        <img src="{{asset('gmail.jpg')}}">
    </a>